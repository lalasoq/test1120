var Rule = {
	"IPv4":/^((25[0-5]|2[0-4]\d|[0-1]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[0-1]?\d\d?)$/,
	"IPv6":/^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/,
	"MAC" :/^(([a-fA-F0-9]){2}(:([a-fA-F0-9]){2}){5})$/,
	"SubnetMask" : /^(((255\.){3}(255|254|252|248|240|224|192|128|0+))|((255\.){2}(255|254|252|248|240|224|192|128|0+)\.0)|((255\.)(255|254|252|248|240|224|192|128|0+)(\.0+){2})|((255|254|252|248|240|224|192|128|0+)(\.0+){3}))$/,
	"Hostname" : /^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$/,
	"Int":/^[0-9]*$/
}

function UTF8CodeCheck(value) {
	var len = value.length;
	var c;
	var i = 0;
	
	for(i = 0; i < len; i++)
	{
		c = value.charCodeAt(i);
		if( (c >= 32) && (c <= 36))
			continue;
		else if( (c >= 38) && (c <= 46))
			continue;
		else if( (c >= 48) && (c <= 59))
			continue;
		else if(c == 61)
			continue;
		else if( (c >= 63) && (c <= 126))
			continue;
		else if(c == 180)
			continue;
		else if( (c == 183) || (c == 184) )
			continue;
		else if( (c >= 192) && (c <= 195) )
			continue;
		else if( (c >= 199) && (c <= 202) )
			continue;
		else if( (c >= 204) && (c <= 206) )
			continue;
		else if( (c>= 209) && (c <= 211) )
			continue;
		else if( (c == 213) || (c == 214) )
			continue;
		else if( (c >= 217) && (c <= 220) )
			continue;
		else if( (c >= 224) && (c <= 227) )
			continue;
		else if( (c >= 231) && (c <= 234) )
			continue;
		else if( (c >= 236) && (c <= 238) )
			continue;
		else if( (c >= 241) && (c <= 243) )
			continue;
		else if( (c == 245) || (c == 246) )
			continue;
		else if( (c >= 249) && (c <= 252) )
			continue;
		else if( c == 8364 )
			continue;
		else
			return true;
	}
	return false;
}

function UTF8CodeCheck_ipv6(value) {
	var len = value.length;
	var c;
	var i = 0;
	
	for(i = 0; i < len; i++)
	{
		c = value.charCodeAt(i);
		if( (c >= 32) && (c <= 36))
			continue;
		else if( (c >= 38) && (c <= 59))
			continue;
		else if(c == 61)
			continue;
		else if( (c >= 63) && (c <= 126))
			continue;
		else if(c == 180)
			continue;
		else if( (c == 183) || (c == 184) )
			continue;
		else if( (c >= 192) && (c <= 195) )
			continue;
		else if( (c >= 199) && (c <= 202) )
			continue;
		else if( (c >= 204) && (c <= 206) )
			continue;
		else if( (c>= 209) && (c <= 211) )
			continue;
		else if( (c == 213) || (c == 214) )
			continue;
		else if( (c >= 217) && (c <= 220) )
			continue;
		else if( (c >= 224) && (c <= 227) )
			continue;
		else if( (c >= 231) && (c <= 234) )
			continue;
		else if( (c >= 236) && (c <= 238) )
			continue;
		else if( (c >= 241) && (c <= 243) )
			continue;
		else if( (c == 245) || (c == 246) )
			continue;
		else if( (c >= 249) && (c <= 252) )
			continue;
		else if( c == 8364 )
			continue;
		else
			return true;
	}
	return false;
}

function isValidIPv4Address(Address)
{
	if(Rule.IPv4.test(Address)){
		return true;
	}
	else{
		return false;
	}
}

function isValidIPv4AddressSubnet(Address)
{
	if(isValidIPv4Address(Address)==false){
		return false;
	}
	else if((Address == "0.0.0.0")||(Address == "255.255.255.255")){
		return false;
	}
	else if(parseInt(Address.split('.')[3]) == 0){
		return false;
	}
	else if(parseInt(Address.split('.')[3]) == 255){
		return false;
	}
	return true;
}

function isValidIPv6Address(Address)
{
	if(Rule.IPv6.test(Address)){
		return true;
	}
	else{
		return false;
	}
}

function isValidSubnetMask(Address)
{
	if(Rule.SubnetMask.test(Address))
	{
		return true;
	}
	else
	{
		return false;
	}
}

function isValidMACAddress(Address)
{
	if(Rule.MAC.test(Address)){
		return true;
	}
	else{
		return false;
	}
}

function isValidASCII(value)
{
	var isVaild = true;

	if(value.length == 0){
		isVaild = false;
	}

	for(var i = 0; i < value.length; i++)
	{
		var charValueDecimal = value.charCodeAt(i);
		if(charValueDecimal < 32 || charValueDecimal > 126){
			isVaild = false;
		}
	}
	return isVaild;
}

function isValidMinute(minute)
{
	if(isNaN(minute))
		return false;
	if(minute < 0 || minute > 59)
		return false;
	return true;
}

function isValidHour(hour)
{
	if(isNaN(hour))
		return false;
	if(hour < 1 || hour > 23)
		return false;
	return true;
}

function isInt(Value)
{
	if(Rule.Int.test(Value)){
		return true;
	}
	else{
		return false;
	}
}

function PortTest(port)
{
	if(port >0 && port <=65535){
		return true;
	}
	else{
		return false;
	}
}