/**
 *
 *	MUI:
 *	https://github.com/muicss/mui
 *
 *	Licensed to the public under the Apache License 2.0
*/
(function ($) {
	$(".main > .loading").fadeOut();

	function trimText(text) {
		return text.replace(/[ \t\n\r]+/g, " ");
	}


	var lastNode = undefined;
	var mainNodeName = undefined;

	var nodeUrl = "";
	(function(node){
		if (node[0] == "admin"){
			luciLocation = [node[1], node[2]];
		}else{
			luciLocation = node;
		}

		for(var i in luciLocation){
			nodeUrl += luciLocation[i];
			if (i != luciLocation.length - 1){
				nodeUrl += "/";
			}
		}
	})(luciLocation);

	function getCurrentNodeByUrl() {
		var ret = false;
		if (!$('body').hasClass('logged-in')) {
			luciLocation = ["Main", "Login"];
			return true;
		}

		$(".main > .main-left > .nav > .slide > .menu").each(function () {
			var ulNode = $(this);
			ulNode.next().find("a").each(function () {
				var that = $(this);
				var href = that.attr("href");

				if (href.indexOf(nodeUrl) != -1) {
					ulNode.click();
					ulNode.next(".slide-menu").stop(true, true);
					lastNode = that.parent();
					lastNode.addClass("active");
					ret = true;
					lastNode_father=lastNode.parent();
					lastNode_father.addClass("activeON");
					return true;
				}
			});
		});
		return ret;
	}

	$(function(){
		var allPanels = $(".main > .main-left > .nav > .slide > .slide-menu").hide();
		var allmenu = $(".main > .main-left > .nav > .slide > .menu");
		$(".main > .main-left > .nav > .slide > .menu").click(function () {
			var ul = $(this).next(".slide-menu");
			var menu = $(this);
			if (ul.hasClass("active")){
				ul.slideUp(function(){
					menu.removeClass("active");
					ul.removeClass("active");
				});
			}
			else{
				allPanels.slideUp().removeClass("active");
				allmenu.removeClass("active");
				menu.addClass("active");
				ul.addClass("active");
				ul.slideDown();
			}
			return false;
		});
		$(".activeON").slideDown();
	});

	$(function(){
		var allPanels = $(".main-left .nav .slide .slide-menu .slide2 .slide-menu2").hide();
		var allmenu = $(".main-left .nav .slide .slide-menu .slide2 .menu2");
		$(".main-left .nav .slide .slide-menu .slide2 .menu2").click(function () {
			var ul = $(this).next(".slide-menu2");
			var menu = $(this);
			if (ul.hasClass("active2")){
				ul.slideUp(function(){
					menu.removeClass("active2");
					ul.removeClass("active2");
				});
			}
			else{
				allPanels.slideUp().removeClass("active2");
				allmenu.removeClass("active2");
				menu.addClass("active2");
				ul.addClass("active2");
				ul.slideDown();
			}
			return false;
		});

		$(".active2").slideDown();
	});

	$(".main > .main-left > .nav > .slide > .slide-menu > li > a").click(function () {
		if (lastNode != undefined) lastNode.removeClass("active");
		$(this).parent().addClass("active");
		$(".main > .loading").fadeIn("fast");
		return true;
	});

	$(".main > .main-left > .nav > .slide > .slide-menu > li").click(function () {
		if (lastNode != undefined) lastNode.removeClass("active");
		$(this).addClass("active");
		$(".main > .loading").fadeIn("fast");
		window.location = $($(this).find("a")[0]).attr("href");
		return false;
	});

	if (getCurrentNodeByUrl()) {
		mainNodeName = "node-" + luciLocation[0] + "-" + luciLocation[1];
		mainNodeName = mainNodeName.replace(/[ \t\n\r\/]+/g, "_").toLowerCase();
		$("body").addClass(mainNodeName);
	}
	$(".cbi-button-up").val("");
	$(".cbi-button-down").val("");

	$("#maincontent > .container").find("a").each(function () {
		var that = $(this);
		var onclick = that.attr("onclick");
		if (onclick == undefined || onclick == "") {
			that.click(function () {
				var href = that.attr("href");
				if (href.indexOf("#") == -1) {
					$(".main > .loading").fadeIn("fast");
					return true;
				}
			});
		}
	});

	var showSide = false;
	$(".showSide").click(function () {
		if (showSide) {
			$(".darkMask").stop(true).fadeOut("fast");
			$(".main-left").stop(true).animate({
				width: "0"
			}, "fast");
			$(".main-right").css("overflow-y", "auto");
			showSide = false;
		} else {
			$(".darkMask").stop(true).fadeIn("fast");
			$(".main-left").stop(true).animate({
				width: "20rem"
			}, "fast");
			$(".main-right").css("overflow-y", "hidden");
			showSide = true;
		}
	});

	$(".CLOSEMENU").click(function () {
		$(".darkMask").stop(true).fadeOut("fast");
		$(".main-left").stop(true).animate({
			width: "0"
		}, "fast");
		$(".main-right").css("overflow-y", "auto");
		showSide = false;
	});
	$(".darkMask").click(function () {
		if (showSide) {
			showSide = false;
			$(".darkMask").stop(true).fadeOut("fast");
			$(".main-left").stop(true).animate({
				width: "0"
			}, "fast");
			$(".main-right").css("overflow-y", "auto");
		}
	});

	$(window).resize(function () {
		if ($(window).width() > 921) {
			$(".main-left").css("width", "");
			$(".darkMask").stop(true);
			$(".darkMask").css("display", "none");
			showSide = false;
		}
	});

	$("legend").each(function () {
		var that = $(this);
		that.after("<span class='panel-title' style='color:white;'>" + that.text() + "</span>");
	});

	$(".cbi-section-table-titles, .cbi-section-table-descr, .cbi-section-descr").each(function () {
		var that = $(this);
		if (that.text().trim() == ""){
			that.css("display", "none");
		}
	});


	$(".main-right").focus();
	$(".main-right").blur();
	$("input").attr("size", "0");

	if (mainNodeName != undefined) {
		console.log(mainNodeName);
		switch (mainNodeName) {
			case "node-status-system_log":
			case "node-status-kernel_log":
				$("#syslog").focus(function () {
					$("#syslog").blur();
					$(".main-right").focus();
					$(".main-right").blur();
				});
				break;
			case "node-status-firewall":
				var button = $(".node-status-firewall > .main fieldset li > a");
				button.addClass("cbi-button cbi-button-reset a-to-btn");
				break;
			case "node-system-reboot":
				var button = $(".node-system-reboot > .main > .main-right fieldset p > a");
				button.addClass("cbi-button cbi-button-reset a-to-btn");
				break;
		}
	}

	if(location.pathname == "/cgi-bin/luci"){
		if( $("[name=SideMenu]").hasClass("main-left") ) {
			$("[name=SideMenu]").removeClass("main-left");
		}
		if( $("[name=MainContent]").hasClass("main-right") ) {
			$("[name=MainContent]").removeClass("main-right");
		}
	}
})(jQuery);
