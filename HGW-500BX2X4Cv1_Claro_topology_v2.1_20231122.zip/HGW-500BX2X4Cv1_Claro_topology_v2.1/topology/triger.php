<?php

echo "trigger refresh data.json";
?>